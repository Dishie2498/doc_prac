"""
Metrics example 1
============================================
Lorem ipsum, dolor sit amet consectetur adipisicing elit.
"""
