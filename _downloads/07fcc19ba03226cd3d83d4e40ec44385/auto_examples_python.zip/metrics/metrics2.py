"""
Metrics example 2
============================================
Lorem ipsum, dolor sit amet consectetur adipisicing elit.
"""
