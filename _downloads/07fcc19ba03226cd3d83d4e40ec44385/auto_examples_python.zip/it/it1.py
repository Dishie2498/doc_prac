"""
Entropy example 1
============================================
Lorem ipsum, dolor sit amet
"""
